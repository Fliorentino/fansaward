<?php $__env->startSection('title', "Ajouter un nouveau statut"); ?>

<!--Contenu-->
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="login-panel panel panel-default">
                    <h4 class="panel-heading">Poster un Statut</h4>
                <div class="panel-body">
                <form action="<?php echo e(route('statut.add')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <div class="row mt-1">
                                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                                            <div class="form-group">
                                            <div class="custom-file">
                                                <input id="file" type="file" class="custom-file-input input-sm" name="fileName" <?php $__errorArgs = ['fileName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> >
                                                <label for="file" class="custom-file-label" aria-valuetext="choisir..."></label>
                                                <?php $__errorArgs = ['fileName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback text-danger">
                                                        <?php echo e($errors->first('fileName')); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="button" class="btn btn-success">Charger le Statut</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--End pop up addStatut-->

<?php $__env->stopSection(); ?>
<!--End contenu-->

<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/ejservice/statut.blade.php ENDPATH**/ ?>
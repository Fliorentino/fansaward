<?php $__env->startSection('title', "Mon profile et mes information personnelles"); ?>
<!--Contenu-->
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col">
                        Réglages : Ajuster mon profile
                    </div>
                    <div class="col">
                    </div>
                </div>
            </div>
        <!--end title-->
        <div class="row">
            <div class="col-lg-3 col-md-6"><a href="<?php echo e(route('users')); ?>" class="btn btn-sm btn-success"><i class="icon-arrow_back"></i>Accueil</a></div>
            <div class="col-lg-3 col-md-6"><a href="<?php echo e(route('statut.new')); ?>" class="btn btn-sm btn-primary"><i class="icon-add_a_photo"></i>Status +</a></div>
            <div class="col-lg-3 col-md-6"><a href="<?php echo e(route('profile.edit', Auth::user()->id)); ?>"  class="btn-sm btn-warning"><i class="icon-settings"></i>Modifier le profile</a></div>
            <div class="col-lg-3 col-md-6"><a href="<?php echo e(route('profile.remove', Auth::user()->id)); ?>"  class="btn-sm btn-danger btn-disabled"><i class="icon-remove2"></i>Supprimer le compte</a></div>
        </div>
            <div class="panel-body mt-5">
                <div class="col-md-12 col-lg-6">
                    
                    <div class="card">
                        <div class="card-image">
                            <?php if(Auth::user()->file == null): ?>
                                <img src="<?php echo e(asset('images/user.png')); ?>" alt="user.photo " class="img-thumbnail">
                            <?php else: ?>
                                <img src="<?php echo e(asset(Auth::user()->file)); ?>" alt="user.photo " class="img-thumbnail">
                            <?php endif; ?>
                          
                        </div>
                        <div class="card-content">
                            <div class="row">
                                <strong>Nom : </strong>&nbsp;<?php echo e(Auth::user()->nom); ?> 
                            </div>
                            <div class="row">
                                <strong>Prénom : </strong>&nbsp;<?php echo e(Auth::user()->prenom); ?> 
                            </div>
                            <div class="row">
                                <strong>Anniversaire : </strong>&nbsp;<?php echo e(Auth::user()->dateNaissance); ?> 
                            </div>
                            <div class="row">
                                <strong>Genre : </strong>&nbsp;<?php echo e(Auth::user()->sexe == 1 ? "Homme" : "Femme"); ?> 
                            </div>
                            <div class="row">
                                <strong> Profession : </strong>&nbsp;<?php echo e(Auth::user()->profession); ?> 
                            </div>
                            <div class="row">
                                <strong> Paroisse : </strong>&nbsp;<?php echo e(Auth::user()->paroisse); ?> 
                            </div>
                            <div class="row">
                                <strong> Quartier : </strong>&nbsp;<?php echo e(Auth::user()->quartier); ?> 
                            </div>
                            <div class="row">
                                <strong> Mail : </strong>&nbsp;<?php echo e(Auth::user()->email); ?> 
                            </div>
                            <div class="row">
                                <strong> Téléphone : </strong>&nbsp;<?php echo e(Auth::user()->telephone); ?> 
                            </div>
                        </div>
                      </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="overflow: visible;">
                        <div class="card-image waves-effect waves-block waves-light">
                          <img class="activator" src="<?php echo e(asset($story->fileName)); ?>">
                        </div>
                        <div class="card-content">
                            <a href=" <?php echo e(route('statut.remove', $story->id)); ?> "><button  class="btn btn-outline-danger mx-auto "><i class="icon-delete"></i></button></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--End contenu-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/ejservice/profile.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "Produits et Services"); ?>

<!--Contenu-->
<?php $__env->startSection('content'); ?>

<!--content-->
<div class="container-fluid">
    <div class="container pt-5 mx-auto">
        <h2 class="text-center text-muted text-monospace">Membres EJ</h2>
        <div class="row">
            <!--Repetition des utilisateurs-->
            <div class="col-sm-12">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <button class="card shadow bg-white  my-4" style="height: auto;min-height: auto;">
                        <?php if($user->file == null): ?>
                            <img src="<?php echo e(asset('images/user.png')); ?>" alt="user.photo " class=" btn-img img-simple img-fluid float-md-left ">
                        <?php else: ?>
                        <img src="<?php echo e(asset($user->file)); ?>" alt="user.photo " class=" btn-img img-simple img-fluid float-md-left ">
                        <?php endif; ?>
                    <h3 class="card-tex"><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></h3>
                        <p class="card-tex "><?php echo e($user->profession); ?></p>
                        <a href="/service/users/<?php echo e($user->id); ?>" class="btn btn-info float-lg-right"><i class="icon-eye"></i>&nbsp;Voir Profil</a>
                    </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--Fin des utilisateurs for-->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--End contenu-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/ejservice/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Profile de <?php echo e($user->nom); ?>' ); ?>

<!--Contenu-->
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="container">
        <!--title (user)-->
        <div class="row ">
            <div class="col text-center">
                <h1 class="display4 text-uppercase text-dark mb-0">
                    <strong>Profile Sélectionner</strong>
                </h1>
                <!--<div class="title-underline bg-primary"></!--<div>-->
                <p class="mt-2 text-muted">Profile de <?php echo e($user->nom); ?></p>
            </div>
        </div>
        <!--end title-->

        <div class="d-flex flex-row">
            <div class="col-md-6 col-sm-12">
             <div class="">
                 <div class="panel-body">
                    <img src="<?php echo e(asset($user->file)); ?>" alt="userSelected" class="card-img-top" style="height:300px!important;">
                    <div class="row">
                        <strong>Nom : </strong>&nbsp;<?php echo e($user->nom); ?> 
                    </div>
                    <div class="row">
                        <strong>Prénom : </strong>&nbsp;<?php echo e($user->prenom); ?> 
                    </div>
                    <div class="row">
                        <strong>Profession : </strong>&nbsp;<?php echo e($user->profession); ?> 
                    </div>
                    <div class="row">
                        <strong>Paroisse : </strong>&nbsp;<?php echo e($user->paroisse); ?> 
                    </div>
                    <div class="row">
                        <strong>Adresse : </strong>&nbsp;<?php echo e($user->quartier); ?> 
                    </div>
                    <div class="row">
                        <strong>Téléphone : </strong>&nbsp;<?php echo e($user->telephone); ?> 
                    </div>


                    <div id="contentSlide">
                        <div class="owl-carousel owl-theme">
                            <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset($story->fileName)); ?>"alt=""Slide images class="laz" width="500px" height="500px"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>   

                 </div>
             </div>   
            </div>


        </div>


       
    </div>
</div>


<?php $__env->stopSection(); ?>
<!--End contenu-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/ejservice/show.blade.php ENDPATH**/ ?>
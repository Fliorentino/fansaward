<?php $__env->startSection('title', 'Accuiell'); ?>
    
<!--nav bar-->
<!--End nav-->

<!--Contenu de la page-->
<?php $__env->startSection('content'); ?>
<section class="bg-white pt-0" id="articles ">
    <div class="container">
        <div class="article row ">
            <!--the one or single article-->
            <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 my-3 ">
                    <div class="card shadow bg-white rounded bording">
                        <img src="<?php echo e(asset($annonce->fileName)); ?>" alt="article1 " class="card-img-top ">
                        <div class="card-body ">
                            <h3 class="card-title "><?php echo e($annonce->titre); ?></h3>
                            <p class="card-text ">
                                <?php echo e($annonce->description); ?>                            
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--End single article-->
        </div>
        <div class="row dflex-justify-content-center mb-2">
            <?php echo e($annonces->links()); ?>

            </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<!--Fin contenu de la page-->

<!--Footer-->
<!--End footer-->

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/index.blade.php ENDPATH**/ ?>
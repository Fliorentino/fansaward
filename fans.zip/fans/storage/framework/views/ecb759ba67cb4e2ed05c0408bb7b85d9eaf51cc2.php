<style>
    .justify-text {
        text-align: justify!important;
    }
</style>
<?php $__env->startSection('title', "Info-Mouvement"); ?>
<!--Contenu-->
<?php $__env->startSection('content'); ?>

   
    <!--content-->
    <div class="container-fluid" style="background-color: #fff;">
        <div class="container pt-5">
            <!--image-->
            <div class="text-center mb-3">
                <div class="border-primary">
                        
                    <div class="presentate">
                        <strong>
                            <h1 class="titre_mouvement">" MOUVEMENT ENFANT JESUS " </h1>
                            <span class="sousTitre">ARCHIDIOCESE DE LOME / DOYENNE LOME-EST <br>
                            Tel : 92 43 27 75 / 98 25 95 35 .
                            </span>
                        </strong> 
                    </div>
                </div>
                <div class="icone">
                    <a class="icone" href="<?php echo e(asset("img/enfantJesus.jpg")); ?>" title="Clickez pour télécharger"> <img src="<?php echo e(asset('img/enfantJesus.jpg')); ?>" alt="logo Enfant Jésus" class="image"></a>
                </div>
            </div>
            <!--end-->

        </div>
        <!--info complementaire-->
        <div class="contaier">
            <div class="card mb-2">
                <h2 class="text-info text-uppercase display-4">Historique</h2>
                <div class= "card-text">
                    Lors de ses séjours sur la paroisse St Antoine de Padoue d'Adakpamé, 
                    le révérend Père Kokou Gilbert SIKA, a décidé de mettre en place un groupe de jeunes qui deviendra plus tard le mouvement Enfant Jésus.
                    Son but était de rassembler ces jeunes dont la plupart n 'appartenaient à aucune association;
                    Ceci pour en créer un groupe dont les objectifs et les caractéristiques différent considérablement des autres. Un soir, il
                    réussit à parler de l'idée à 3 jeunes filles qui ont apprécié son idée et ont décidé de l 'aider à la concrétiser. 
                    Au début ce ne fut qu'un rassemblement de 3 - 4 personnes avec le Père lui-même pour approfondir la
                    compréhension des objectifs et orientations de ce nouveau mouvement. 
                    En suite, avec l 'invitation de leurs amis, connaissances, et l'attrait de ses objectifs et son but , le mouvement grandit très vite en éffectif;
                    d 'où la nécessité d'instaurer une administration: 
                    Un <em>président</em> pour coordonner les rencontres, <em>un secrétaire, un trésorier , un chargé à l'organisation</em> et <em>un animateur</em> .En tout cinq(5) personnes
                    pour menner le reste des membres du mouvement aux objectifs et but du mouvement. Tout ceci a commencé avec les jeunes de la paroisse St Antoine de Padoue d'Adakpamé; 
                    mais plus tard, le mouvement sera présent sur deux
                    autres communautés à savoir: communauté<em> Sts Pierre et Paul de Kagomé</em>, Paroisse <em>Ste Maria Auxiliadora de Gbényédzi</em> et bientôt sur la paroisse <em>Notre Dame de Lourdes </em> Bè-Adidomé.
                    </div>
            </div>

            <div class="card mb-2">
                <h2 class="text-success text-uppercase display-4">Présentation</h2>
                <div class= "card-text">
                                Le mouvement <strong>"Enfant Jésus "</strong> est un mouvement de jeunes dont l'âge est compris entre 15 et 25 ans 
                    (Au delà de cette tranche d'âge, nous parlerons d'une catégorie adulte...). Créé par le Révérend
                    Père Gilbert SIKA lors de ses séjours en tant que diacre sur la Paroisse St Antoine de Padoue d'Adakpamé, 
                    il a pour but de donner à tout jeune désireux, un environnement de formation, d'entraide, une bonne vie d'équipe
                    et une orientation de leur énergie vers la pleine réalisation de leur vie. 
                    Des formations (sur le plan social, spirituel, éducatif, sanitaire, entrepreneurial, relationnel, comportemental,...) sont données par les encadreurs
                    et formateurs du mouvement. 
                    Quant à l'entraide, les membres du mouvement Enfant Jésus se sont aussi donnés pour mission de se partager les connaissances professionnelles et extra-professionnelles de leurs divers domaines
                    d'où un remarquable entraide au sein des membres.
            
                    <p>
                        <strong> Les valeurs recommandées </strong>aux membres du mouvement sont: la solidarité, l'entraide et le respect de son corps. 
                        <strong> Les piliers du mouvement :</strong> La prière, la parole de Dieu, le mode de vie, la correction fraternelle et le témoignage de vie.

                    </p>
                    </div>
            </div>

            <div class="card mb-2">
                <h2 class="text-info text-uppercase display-4">Spiritualité</h2>
                <div class= "card-text">
                        <h5 style="color: blue;"> Grandir en sagesse et en intelligence comme l'Enfant Jésus !</h5>
                        Cette phrase constitue la spiritualité du mouvement Enfant Jésus. 
                        En effet, tout membre du mouvement a un modèle commun qui est l'Enfant Jésus, à travers son image; 
                        assis parmi les docteurs de la lois, les écoutant et les intérrogeant; et dont St Luc
                        témoigne l'intelligence et la sagesse à l'égard de Dieu et des hommes à travers le 52 eme verset de son évangile:
                        <em> <strong>  "Et Jésus croissait en sagesse, en stature, et en grâce devant Dieu et devant les hommes" </strong> </em>
                        <p class="bg-info">
                            cette spiritualité constitue aussi la prière du mouvement Enfant Jésus: <br> <em class="text-danger">Enfant Jésus, aide-moi à grandir en sagesse et en intelligence comme toi !</em>
                        </p>
                </div>
            </div>

            <div class="card mb-2">
                <h2 class="text-info text-uppercase display-4"> salutation</h2>
                <br><strong> <h5 class="text-success"> Rien par Force!!!, Tout par Amour!!! </h5></strong>
                <div class= "card-text">
                    Inspirée de la spiritualité de saint François de Sale, cette phrase constitue la salutation que doit adresser tout membre du mouvement
                    Enfant Jésus à son homologue à chaque fois qu'ils se rencontrent. En effet pour parvenir aux objectifs qui sous-tendent
                   le mouvement, Les membres du mouvement doivent essayer de tout faire par Amour. 
                   Et au-delà de cette considération, nous devons respecter le commandement de l'Amour que nous recommande le Seigneur. 
                   Aimez-vous les uns les
                   autres comme je vous aime!
                </div>
            </div>

            <div class="card mb-2">
                <h2 class="text-warning text-uppercase display-4">Caractères distinctifs</h2>
                <div class= "card-text">
                    <br><strong><span class="bg-warning">La Joie </span>, <span class="bg-success">la douceur</span> et <span class="bg-info">la Simplicité</span></strong> ! <br> Les 3 caractères distinctifs d'un membre du mouvement <em>Enfant Jésus</em> sont: <br>
                    La <em>joie</em> qu'il communique à son entourage quelque soient les sentiments qui y prévalent. <br> La <em> douceur</em> qu'il témoigne dans certaines circonstances de la vie, sa différence de réagir comparé au
                    reste du monde. <br> La <em>Simplicité</em> qu'il montre dans ses relations avec sa société.
                </div>
            </div>

            <div class="card mb-2">
                <h2 class="text-info text-uppercase display-4">Les activités du mouvement</h2>
                <div class= "card-body">
                    <p>
                        <ul>
                            <li>Les réunions ou rencontres ordinaires tous les dimanches</li>
                            <li>Les sorties</li>
                            <li>Les camps de formation, de loisir et de mission </li>
                            <li>Les récollections</li>
                            <li>Les retraites</li>
                            <li>Les activités manuelles</li>
                            <li>Les formations</li>
                            <li>Les causeries et débats</li>
                            <li>Les visites aux malades, aux prisonniers et aux nécessiteux</li>
                            <li>Les fêtes patronales et autres fêtes liées au mouvement(anniversaire de création, ...)</li>
                        </ul>
                    </p>                </div>
            </div>

        </div>
        <!--End info complementaire-->
    </div>

<?php $__env->stopSection(); ?>
<!--End contenu-->

<!--Footer-->
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<!--End footer-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/info.blade.php ENDPATH**/ ?>
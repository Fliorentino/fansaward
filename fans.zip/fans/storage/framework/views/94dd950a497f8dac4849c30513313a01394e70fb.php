<?php $__env->startSection('title', 'Profile de <?php echo e($user->nom); ?>' ); ?>

<!--Contenu-->
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Profile de <?php echo e($user->nom); ?> <?php echo e($user->prenom); ?> 
            </div>
            <div class="panel-body">
                <div class="col-md-12 col-lg-6">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset($user->file)); ?>" alt="userSelected" class="card-img-top" style="height:300px!important;">
                        </div>
                        <div class="timeline-body">
                          <span class="card-title"></span>
                            <p>
                                <div class="row">
                                    <strong>Nom : </strong>&nbsp;<?php echo e($user->nom); ?> 
                                </div>
                                <div class="row">
                                    <strong>Prénom : </strong>&nbsp;<?php echo e($user->prenom); ?> 
                                </div>
                                <div class="row">
                                    <strong>Genre  : </strong>&nbsp;<?php echo e($user->sexe == 1 ? "Homme" : "Femme"); ?> 
                                </div>
                                <div class="row">
                                    <strong>Profession : </strong>&nbsp;<?php echo e($user->profession); ?> 
                                </div>
                                <div class="row">
                                    <strong>Paroisse : </strong>&nbsp;<?php echo e($user->paroisse); ?> 
                                </div>
                                <div class="row">
                                    <strong>Adresse : </strong>&nbsp;<?php echo e($user->quartier); ?> 
                                </div>
                                <div class="row">
                                    <strong>Téléphone : </strong>&nbsp;<?php echo e($user->telephone); ?> 
                                </div>
                            </p>
                        </div>
                      </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div id="contentSlide">
                        <div class="owl-carousel owl-theme">
                            <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset($story->fileName)); ?>"alt=""Slide images class="laz" width="500px" height="500px"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--End contenu-->

<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/ejservice/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "Produits et Services"); ?>

<!--Contenu-->
<?php $__env->startSection('content'); ?>

<!--content-->
<div class="row">
    <div class="col-lg-12">
        <div class="panel" style="background-color: #f2f8f6">
            <div class="panel-heading"><strong>Membres EJ</strong></div>
            <div class="panel-body">
                <div class="col-md-12">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <!--Repetition des utilisateurs-->
                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <div class="card horizontal">
                            <div class="card-image">
                                    <?php if($user->file == null): ?>
                                        <img src="<?php echo e(asset('images/user.png')); ?>" alt="user.photo " class="img-thumbnail">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset($user->file)); ?>" alt="user.photo " class="img-thumbnail">
                                    <?php endif; ?>
                            </div>
                            <div class="card-stacked">
                                <div class="card-content">
                                    <p class="card-text">
                                        <h3 class="card-text"><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></h3>
                                        <?php echo e($user->profession); ?>

                                    </p>
                                </div>
                                <div class="card-action">
                                    <a href="/service/users/<?php echo e($user->id); ?>" class="btn btn-info float-lg-right"><i class="icon-eye"></i>&nbsp;Voir Profil</a>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--Fin des utilisateurs for-->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--End contenu-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/ejservice/index.blade.php ENDPATH**/ ?>
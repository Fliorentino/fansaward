<?php $__env->startSection('statistic'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Liste des utilisateurs</div>
            <div class="panel-body">
                <div class="col-md-12">

                    <table class="table table-striped">
                        <thead>
                        <tr class="bg-info">
                            <th scope="col">#</th>
                            <th scope="col">Titre</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($annonce->id); ?></td>
                                <td><?php echo e($annonce->titre); ?></td>
                                <td>
                                    <a href="/admin/<?php echo e($annonce->id); ?>/editer" class="btn btn-success btn-sm"><i class="icon-edit"></i>&nbsp;Editer</a>
                                    <a href="/admin/<?php echo e($annonce->id); ?>" class="btn btn-danger btn-sm"><i class="icon-delete"></i>&nbsp;Suprimer</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views//admin/listeAnnonces.blade.php ENDPATH**/ ?>
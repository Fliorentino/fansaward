<?php $__env->startSection('statistic'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" >
    <div class="card">
        <div class="card-header">
          <h3>Assignation de rôle d'administrateur à un utilisateur </h3>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                <tr class="bg-info">
                    <th scope="col">#</th>
                    <th scope="col">Nom</th>
                    <th scope="col">prenom</th>
                    <th scope="col">telephone</th>
                    <th scope="col">paroisse</th>
                    <th scope="col">Rôle</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $listUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($utilisateur->id); ?></td>
                        <td><?php echo e($utilisateur->nom); ?></td>
                        <td><?php echo e($utilisateur->prenom); ?></td>
                        <td><?php echo e($utilisateur->telephone); ?></td>
                        <td><?php echo e($utilisateur->paroisse); ?></td>
                        <td>
                        <a href="/admin/<?php echo e($utilisateur->id); ?>/valide" class="btn btn-danger btn-lg"><i class="icon-check">&nbsp;</i>Assigner</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views//admin/nouveauAdmin.blade.php ENDPATH**/ ?>
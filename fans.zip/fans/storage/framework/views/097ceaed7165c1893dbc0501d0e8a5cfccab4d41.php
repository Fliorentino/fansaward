<!DOCTYPE html>
<html>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Enfant Jésus | <?php echo $__env->yieldContent('title'); ?></title>
	<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('icon/icons.css')); ?>">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owlgreen.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>">

	<style>
        .button-user {
            margin-right:80px!important;
        }
    </style>

	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
	<script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand">Enfant&nbsp;Jésus</a>
				<ul class="nav navbar-top-links navbar-right">
			
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
                <?php if(Session::get('id')): ?>
                <img src="<?php echo e(asset(Auth::user()->file)); ?>" class="img-responsive" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('images/user.png')); ?>" class="img-responsive" alt="">
                <?php endif; ?>
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"></div>
				<div class="profile-usertitle-status">
                  <?php if(Session::get('id')): ?>
                    <span class="indicator label-success">
                          </span>En ligne
                  <?php else: ?>
                    <span class="indicator label-dark">
                          </span>Non connecté
                  <?php endif; ?>
                </div>
                
			</div>
			<div class="clear">
            </div>
        </div>
        <div class="divider"></div>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?> 
            <div class="nav menu">
            <li>
                <a href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
                       <i class="icon-sign-out" type="button"></i>&nbsp;<?php echo e(__('Se déconnecter')); ?>

               </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                   <?php echo csrf_field(); ?>
               </form>
            </li>
            <li><a class="dropdown-item all-button" href="<?php echo e(route('profile.view')); ?>"><i class="icon-person">&nbsp;</i> Mon Profil</a></li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager-users')): ?>
            <li><a class="dropdown-item all-button" href="<?php echo e(route('acceuil')); ?>"><i class="icon-dashboard">&nbsp;</i>Tableau de bord</a></li>
               <?php endif; ?>
            </div>
        <?php endif; ?>
		<div class="divider"></div>
		<ul class="nav menu">
			<li class="active"><a href="<?php echo e(route('home')); ?>"><em class="icon-home">&nbsp;</em> Acceuill</a></li>
            <li><a href="<?php echo e(route('users')); ?>"><em class="icon-work">&nbsp;</em>Produits & Services</a></li>
            <li><a href="<?php echo e(route('info')); ?>"><em class="icon-info_outline">&nbsp;</em>Apropos du Mouvement</a></li>
            <li><a href="<?php echo e(route('programme')); ?>"><em class="icon-calendar-o">&nbsp;</em>Programme de l'année</a></li>
            <li><a href="<?php echo e(route('bestmoments')); ?>"><em class="icon-fire">&nbsp;</em>Moments forts</a></li>
            <?php if(auth()->guard()->guest()): ?>
            <li><a href="<?php echo e(route('login')); ?>"><i class="icon-sign-in"></i>&nbsp;<?php echo e(__('Se Connecter')); ?></a></li>
            <?php if(Route::has('register')): ?> 
                <li><a href="<?php echo e(route('register')); ?>"><i class="icon-user-plus"></i>&nbsp;<?php echo e(__('Créer mon Compte')); ?></a></li>
            <?php endif; ?>  
            <?php endif; ?>
        </ul>   
	</div><!--/.sidebar-->
    
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
            <?php if(Session::has('nonValide')): ?>
            <div class="alert alert-warning " >
              <?php echo e(Session::get('nonValide')); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('creation')): ?>
            <div class="alert bg-teal" >
              <?php echo e(Session::get('creation')); ?>

            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
			<div class="col-sm-12 mt-3">
				<p class="back-link">&copy; 2019 Enfant Jésus réalisé par <a href="https://mfn-32.webself.net/">mfn Inc.</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.slide.js')); ?>"></script>
		
</body>
</html>
<head><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/layouts/newlayout.blade.php ENDPATH**/ ?>
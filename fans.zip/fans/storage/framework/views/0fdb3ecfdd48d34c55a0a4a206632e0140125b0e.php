<?php $__env->startSection('title', "Mon profile et mes information personnelles"); ?>
<!--Contenu-->
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="container">
        <!--title (user)-->
        <div class="row ">
            <div class="col text-center">
                <h1 class="display4 text-uppercase text-dark mb-0">
                    <strong>Réglage</strong>
                </h1>
                <!--<div class="title-underline bg-primary"></!--<div>-->
                <p class="mt-2 text-muted">Ajuster mon Profil</p>
            </div>
        </div>
        <!--end title-->
        <div class="d-flex flex-row">
           <div class="col-md-12">
            <div class="">
                <div class="panel-body">
                    <a href="<?php echo e(route('users')); ?>" class="btn btn-sm btn-success"><i class="icon-arrow_back"></i>Aller a l'accueil</a>
                    <a href="<?php echo e(route('statut.new')); ?>" class="btn btn-sm btn-primary"><i class="icon-add_a_photo"></i>Ajouter Un status</a>
                    <a href="<?php echo e(route('profile.edit', Auth::user()->id)); ?>"  class="btn-sm btn-warning"><i class="icon-settings"></i>Modifier Mon profile</a>
                    <a href="<?php echo e(route('profile.remove', Auth::user()->id)); ?>"  class="btn-sm btn-danger"><i class="icon-remove2"></i>Supprimer mon compte</a>
                </div>
            </div>   
           </div>
        </div>
        <div class="row">
            <!--user look form like card-->
            <div class="col-sm-12 col-md-3 col-lg-3 my-2">
                <div class="card">
                <img src="<?php echo e(asset(Auth::user()->file)); ?>" alt="userSelected" class=" img-thumbnail">
                </div>
            </div>
            
            <!--End user card-->
            <div class="col-sm-12 col-md-3 col-lg-3 my-2">
                <div class="row">
                    <strong>Nom : </strong>&nbsp;<?php echo e(Auth::user()->nom); ?> 
                </div>
                <div class="row">
                    <strong>Prénom : </strong>&nbsp;<?php echo e(Auth::user()->prenom); ?> 
                </div>
                <div class="row">
                    <strong>Anniversaire : </strong>&nbsp;<?php echo e(Auth::user()->dateNaissance); ?> 
                </div>
                <div class="row">
                    <strong>Genre : </strong>&nbsp;<?php echo e(Auth::user()->sexe == 1 ? "Homme" : "Femme"); ?> 
                </div>
                <div class="row">
                    <strong> Profession : </strong>&nbsp;<?php echo e(Auth::user()->profession); ?> 
                </div>
                <div class="row">
                    <strong> Paroisse : </strong>&nbsp;<?php echo e(Auth::user()->paroisse); ?> 
                </div>
                <div class="row">
                    <strong> Quartier : </strong>&nbsp;<?php echo e(Auth::user()->quartier); ?> 
                </div>
                <div class="row">
                    <strong> Mail : </strong>&nbsp;<?php echo e(Auth::user()->email); ?> 
                </div>
                <div class="row">
                    <strong> Téléphone : </strong>&nbsp;<?php echo e(Auth::user()->telephone); ?> 
                </div>
            </div>
        </div>

        <div class="row mt-2">
            <!--story of user slide-->
            <div class="col-md-8 ofsset-4">
               <!-- displaying statut-->
                    <div class="panel">
                            <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <button class="shadow-sm bg-white  my-1" style="height: auto;min-height: auto;">
                                <img src="<?php echo e(asset($story->fileName)); ?>" alt="user " class="img-thumbnail img-simple float-md-left">
                                <a href=" <?php echo e(route('statut.remove', $story->id)); ?> "><button  class="btn btn-outline-danger mx-auto "><i class="icon-delete"></i></button></a>
                            </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--End contenu-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/ejservice/profile.blade.php ENDPATH**/ ?>
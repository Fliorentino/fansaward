<?php $__env->startSection('statistic'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Liste des utilisateurs</div>
            <div class="panel-body">
                <div class="col-md-12">
                    <table class="table table-striped">
                        <thead>
                            <tr class="bg-info">
                                <th scope="col">#</th>
                                <th scope="col">Nom</th>
                                <th scope="col">prenom</th>
                                <th scope="col">telephone</th>
                                <th scope="col">paroisse</th>
                                <th scope="col">action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($utilisateur->id); ?></td>
                                    <td><?php echo e($utilisateur->nom); ?></td>
                                    <td><?php echo e($utilisateur->prenom); ?></td>
                                    <td><?php echo e($utilisateur->telephone); ?></td>
                                    <td><?php echo e($utilisateur->paroisse); ?></td>
                                    <td>
                                    <a href="<?php echo e(route('admin.suprimer' ,$utilisateur->id)); ?>" class="btn btn-danger btn-sm"><i class="icon-delete">&nbsp;</i>Supprimer</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views//admin/liste.blade.php ENDPATH**/ ?>
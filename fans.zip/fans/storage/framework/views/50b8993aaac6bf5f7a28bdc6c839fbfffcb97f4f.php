<!DOCTYPE html>
<html>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Tableau de bord</title>
	<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('icon/icons.css')); ?>">
	<link href="<?php echo e(asset('css/datepicker3.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
	<script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>EJ</span>Admin</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="icon-notifications"></em><span class="label label-danger"><?php echo e($nombreDemande); ?></span>
					</a>
						<ul class="dropdown-menu dropdown-messages">
                            <?php $__currentLoopData = $listeDemande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="dropdown-messages-box">
                                        <div class="message-body">
                                            <p> <?php echo e($demande->nom); ?> <?php echo e($demande->prenom); ?> a crée un compte</p>
                                                <span class="date"><?php echo e($demande->created_at); ?>.</span></div>
                                    </div>
                                </li>
                                <li class="divider"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<li>
								<div class="all-button"><a href="<?php echo e(route('admin.demande')); ?>">
									<em class="icon-reply-all">&nbsp;</em><strong>Tous les demandes</strong>
								</a></div>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><?php echo e(Auth::user()->nom); ?></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>En ligne</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li class="active"><a href="<?php echo e(route('acceuil')); ?>"><em class="icon-home">&nbsp;</em> Acceuill</a></li>
			<li><a href="<?php echo e(route('admin.demande')); ?>"><em class="icon-bar-chart">&nbsp;</em>Demande</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="icon-users">&nbsp;</em> Gestion des users<span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="icon-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
                <li><a class="" href="<?php echo e(route('admin.liste.users')); ?>">
						<span class="icon-list-alt">&nbsp;</span> Liste des utilisteurs
					</a></li>
					<li><a class="" href="<?php echo e(route('admin.liste.usersadmin')); ?>">
						<span class="icon-list">&nbsp;</span>Liste des admins
					</a></li>
				</ul>
            </li>
            <li class="parent "><a data-toggle="collapse" href="#sub-item-2">
				<em class="icon-align-left">&nbsp;</em> Gestion d'annonces<span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="icon-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li><a class="" href="<?php echo e(route('annonce.liste')); ?>">
						<span class="icon-list-alt"></span>Liste des annonces
					</a></li>
					<li><a class="" href="<?php echo e(route('annonce.creer')); ?>">
						<span class="icon-announcement">&nbsp;</span>Creer une annonce
					</a></li>
				</ul>
			</li>
			<li><a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
				document.getElementById('logout-form').submit();"><i class="icon-sign-out" type="button">&nbsp;</i>
				  <?php echo e(__('Se déconnecter')); ?>

			 </a>
			 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
				 <?php echo csrf_field(); ?>
			 </form>
			</li>
		</ul>
	</div><!--/.sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('home')); ?>">
					<em class="icon-home"></em>
				</a></li>
				<li class="active">Tableau de bord</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Tableau de bord</h1>
			</div>
        </div><!--/.row-->
        <?php $__env->startSection('statistic'); ?> 
		<div class="panel panel-container">
			<div class="row">
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding"><em class="icon-group color-blue"></em>
							<div class="large">120</div>
							<div class="text-muted">Utilisateurs en ligne</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="icon-comments color-orange"></em>
							<div class="large">52</div>
							<div class="text-muted">Total des annonces</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="icon-user color-teal"></em>
							<div class="large">24</div>
							<div class="text-muted">Nouveaux inscrits</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="icon-users color-red"></em>
							<div class="large">25.2k</div>
							<div class="text-muted">Total Utilisateurs</div>
						</div>
					</div>
				</div>
            </div><!--/.row-->
            <?php echo $__env->yieldSection(); ?>   
            <?php echo $__env->yieldContent('content'); ?>
			<div class="col-sm-12">
				<p class="back-link">Lumino Theme by <a href="https://www.medialoot.com">Medialoot</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/easypiechart.js')); ?>"></script>
	<script src="<?php echo e(asset('js/easypiechart-data.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
	<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>
<head><?php /**PATH /home/tobby/ejlaravel/resources/views/layouts/admin.blade.php ENDPATH**/ ?>
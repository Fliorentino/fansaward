<?php $__env->startSection('statistic'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h4>Détails sur l'utilisateur :<?php echo e($utilisateur->nom); ?> <?php echo e($utilisateur->prenom); ?> de la paroisse <?php echo e($utilisateur->paroisse); ?></h4>
<div class="container bg-primary" style="color:white ; size:16px">
    <table class="table">
      <tr>
        <td ><?php echo e($utilisateur->nom); ?></td>
        <td ><?php echo e($utilisateur->prenom); ?></td>
        <td ><?php echo e($utilisateur->quartier); ?></td>
      </tr>
      <tr>
        <td> <?php echo e($utilisateur->paroisse); ?></td>
        <td><?php echo e($utilisateur->telephone); ?></td>
        <td><?php echo e($utilisateur->email); ?></td>
        </tr>
      <tr>
        <td><?php echo e($utilisateur->profession); ?></td>
        <td><?php echo e($utilisateur->identifiant); ?></td>
        <td><?php echo e($utilisateur->password); ?></td>
      </tr>
      <tr>
        <td>
            <?php if( $utilisateur->sexe == 1 ): ?>
              Masculin
            <?php else: ?>
              Féminin
            <?php endif; ?>  
        </td>
        <td><?php echo e($utilisateur->dateNaissance); ?></td>
        <td><?php echo e($utilisateur->imageFile); ?></td>
      </tr>
      <tr>
         <td><?php echo e($utilisateur->commentaire); ?></td>
         <td>
             <?php if( $utilisateur->valide == 0 ): ?>
               <span style="color:red">En Attente de validation</span>
             <?php else: ?>
                valider
             <?php endif; ?>
         </td>
    </tr>
    </table>
</div>
<div class="text-center my-sm-2" style="display:inline-block">
    <div class="col-md-12">
       <a href="/admin/demande" class="btn btn-secondary btn-lg w-30" >&nbsp;Refuser</button>
       <a href="/admin/<?php echo e($utilisateur->id); ?>/valide" class="btn btn-success btn-lg w-30">&nbsp;Valider</a>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views//admin/details.blade.php ENDPATH**/ ?>
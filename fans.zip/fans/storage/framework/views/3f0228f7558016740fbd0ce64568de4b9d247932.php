<?php $__env->startComponent('mail::message'); ?>
# Salut,

Vous avez recu un message de la part de <?php echo e($data['name']); ?> -- <?php echo e($data['email']); ?>..

Message : <?php echo e($data['message']); ?>


<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/tobby/ejlaravel/resources/views/emails/contact-form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "Accueill"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 text-center">
        <?php if(session('status')): ?>
            <div class="alert bg-info" role="alert">
                <em class="fa fa-lg fa-warning">&nbsp;</em>
                <?php echo e(session('status')); ?>

                <a href="#" class="pull-right"><em class="icon-times"></em></a>
            </div>
        <?php endif; ?>
    </div>
</div>

<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Principaux annonces</div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <!--Les annonces-->
                        <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="panel panel-default">
                                <div class="panel-heading mb-2"><h3><?php echo e($annonce->titre); ?></h3></div>
                                <div class="panel-body">
                                    <img src="<?php echo e(asset($annonce->fileName)); ?>" alt="article1 " class="img-thumbnail">
                                    <p class="panel-text"><?php echo e($annonce->description); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row d-flex-justify-content-center mb-2">
                            <?php echo e($annonces->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/home.blade.php ENDPATH**/ ?>
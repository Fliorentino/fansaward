
    <div class="container text-center mt-5">
       the laravel fansaward
    </div>
<?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/index.blade.php ENDPATH**/ ?>
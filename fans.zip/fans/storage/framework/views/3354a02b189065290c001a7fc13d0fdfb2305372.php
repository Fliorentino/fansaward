<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap-4.1/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('icon/icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/owlgreen.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

        <title>Enfant Jésus | <?php echo $__env->yieldContent('title'); ?></title>

    </head>

    <body>
        
        <!--Navigation bar-->
        <div>
            <!--Navabar-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed">
          <div class="container ">
             <a class="navbar-brand text-uppercase" href="#">Enfant Jésus</a>
            <button class="navbar-toggler d-lg-none " src="button " data-toggle="collapse " data-target="#collapsibleNavId " aria-controls="collapsibleNavId " aria-expanded="false " aria-label="Toggle navigation ">
            <span class="navbar-toggler-icon "></span>
        </button>
            <div class=" navNew collapse navbar-collapse " id="collapsibleNavId ">
                <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix ">
                    <li class="nav-item ">
                        <a class="nav-link active" href="/"><i class="icon-home"></i>&nbsp;Acceuil <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('users')); ?>"><i class="icon-tasks"></i>&nbsp;Produits & Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('info')); ?>"><i class="icon-info-circle"></i>&nbsp;A propos du Mouvement</a>
                    </li>
                    <li class="nav-item">
                             <!-- Authentication Links -->
                             <?php if(auth()->guard()->guest()): ?>
                             <li class="nav-item">
                                 <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                             </li>
                             <?php if(Route::has('register')): ?>
                                 <li class="nav-item">
                                     <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                 </li>
                             <?php endif; ?>
                         <?php else: ?>
                             <li class="nav-item dropdown">
                                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                     <?php echo e(Auth::user()->nom); ?> <span class="caret"></span>
                                 </a>
 
                                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                      document.getElementById('logout-form').submit();">
                                         <i class="icon-sign-out" type="button"></i>&nbsp;<?php echo e(__('Se déconnecter')); ?>

                                     </a>
                                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                         <?php echo csrf_field(); ?>
                                     </form>
                                     <a class="dropdown-item" href="<?php echo e(route('profile.view')); ?>"><i class="icon-person">&nbsp;</i> Mon Profil</a>
                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager-users')): ?>
                                        <a class="dropdown-item" href="<?php echo e(route('acceuil')); ?>"><i class="icon-dashboard">&nbsp;</i>Tableau de bord</a>
                                     <?php endif; ?>
                                 </div>
                             </li>
                         <?php endif; ?>
                    </li>
                </ul>
                <!-- L'utilisateur connecte-->
                <ul class="nav navbar navbar-right mx-2">
                    <li class="nav-item">
                        <a class="nav-link" href="services/user/profile" class=" dropdown-item nav-link">
                            
                        </a>
                    </li>
                </ul>
                <!--Fin de user connected-->
            </div>
        </div>
    </nav>
    <!--!navbar-->
</div>

<!--Tout le contenu-->
<?php echo $__env->yieldContent('content'); ?>
<!--End contenu-->

<!--Footer-->
<div>
    <footer>
        <!-- Copyright Section Start -->
        <div class="copyright ">
            <div class=" ">
                <div class="row ">
                    <div class="col-lg-6 col-md-6 col-xs-12 ">
                        <div class="social-icon text-center ">
                            <a class="facebook " href=""><i class="icon-facebook "></i></a>
                            <a class="twitter " href=""><i class="icon-twitter "></i></a>
                        </div>
                    </div>
                    <div class="mt-2 col-lg-6 col-md-6 col-xs-12 ">
                        <p>&copy; mfn Inc. 2019 mivelfolylogovi</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright Section End -->
    </footer>
</div>
<!--End footer-->

<script src="<?php echo e(asset('css/bootstrap-4.1/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('css/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.slide.js')); ?>"></script>
</body>

</html><?php /**PATH /home/tobby/ejlaravel/resources/views/layouts/layout.blade.php ENDPATH**/ ?>
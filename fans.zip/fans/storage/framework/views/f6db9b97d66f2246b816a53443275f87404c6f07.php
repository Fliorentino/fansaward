<?php $__env->startSection('title', "Accueill"); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
     <?php if(session('status')): ?>
       <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

       </div>
     <?php endif; ?>
         
    <section class="bg-white pt-0" id="articles ">
        <div class="container">
            <div class="article row ">
                <!--the one or single article-->
                <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 my-3 col-md-8 col-lg-7 offset-4">
                        <div class="card shadow bg-white rounded bording">
                            <img src="<?php echo e(asset($annonce->fileName)); ?>" alt="article1 " class="card-img-top ">
                            <div class="card-body ">
                                <h3 class="card-title "><?php echo e($annonce->titre); ?></h3>
                                <p class="card-text ">
                                    <?php echo e($annonce->description); ?>                            
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!--End single article-->
            </div>
            <div class="row dflex-justify-content-center mb-2">
                <?php echo e($annonces->links()); ?>

                </div>
        </div>
    </section>
 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "Moments fort du mouvement"); ?>
<!--Contenu-->
<?php $__env->startSection('content'); ?>

    <!--content-->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Moment forts du mouvement</div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <!--Moments forts du mouvement-->
                        <!--images slider-->
                        <div id="contentSlide" class=" mt-2 my-2 shadow-sm">
                            <div class="owl-carousel owl-theme">
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/1.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/4.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/6.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/8.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/10.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/11.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/12.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/15.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/21.jpg" )); ?>"alt=""Slide images class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/22.jpg")); ?>" alt="Slide images" class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/23.jpg")); ?>" alt="Slide images" class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/24.jpg")); ?>" alt="Slide images" class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/25.jpg")); ?>" alt="Slide images" class="laz" width="100%"></div>
                                <div class="item"><img class="owl-lazy" data-src="<?php echo e(asset("img/27.jpg")); ?>" alt="Slide images" class="laz" width="100%"></div>
                            </div>
                        </div>
                        <!--!image slider-->
                        <br> <br> 
                        <div class="card text-left  shadow px-2">
                            <div class="textMomentForts  mt-2 my-2 mx-4">
                                <p>
                                &nbsp; Les moments forts constituent les moments de vivre ensemble des membres du mouvement venant donc de divers horizons pour atteindre un objectif donné. Les activités qui offrent ces moments de vivre ensemble sont entre autres : <br>                                <br>
                                </p>
                                <p>
                                    <span class="activite">Les camps: </span>Il s'agit d'une grande rencontre que le mouvement effectue une fois chaque année dans le but de faire une projection dans l'avenir du mouvement, pour la formation, les loisirs et
                                    changement d'air des membres du mouvement. Les camps se font généralement sur une période de 5 jours voire une semaine parfois. Ainsi les camps diffèrent selon les objectifs fixés. On distingue pour le mouvement
                                    <em>"Enfant Jésus</em>:
                                    <br>
                                    <em>Les camps mission, les camps de formation ,les camps de loisirs et parfois une combinaison des trois.</em>
                                </p>

                                <p>
                                    <span class="activite">Les recollections, les retraites, les sorties, les réunions ...</span> constituent aussi des moments de vivre ensemble !
                                </p>
                                <p>
                                    Voyez donc enhaut de la page un aperçu des moments que nous passons en famille dans le mouvement "Enfant Jésus" ! En effet ,si vous appartenez à cette grande famille mais que vous ne participez pas à ces activités, sachez que vous n'en faites pas partie réellement
                                    !
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--!content-->

<?php $__env->stopSection(); ?>
<!--End contenu-->

<!--Footer-->
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<!--End footer-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geoffrey/Data/Pro/ejlaravel/resources/views/moment.blade.php ENDPATH**/ ?>
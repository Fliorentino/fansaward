<?php $__env->startSection('title', "Programme de l'année en cours"); ?>
<!--Contenu-->
<?php $__env->startSection('content'); ?>

    <!--content-->
    <div class="container-fluid" style="background-color: #fff;">
        <div class="container pt-5">
                <!--Historique du mouvement-->
                    <div class="container">
                        <div class="text-center">
                            <div class="text-lead"> <br>
                                <h1 class="titres" >Thème général de l'année 2018 - 2019 </h1>
                                <p class="text-secondary" style="color: rgb(117, 157, 209) !important; font-size: 20px !important;">Fraterniser avec "l'Enfant Jésus" pour une jeunesse engagée et un monde meilleur </p> <br>
                                <h1 class="titres">But: </h1> 
                                <p class="text-secondary" style="color :rgb(117, 157, 209) !important; font-size: 20px !important;">
                                    Être sage et intelligent comme l'Enfant Jésus
                                </p> <br>
                                <h1 class="titres">Objectif général:</h1>
                                <p class="text" style="color: rgb(117, 157, 209) !important; font-size: 20px !important;">Pour un mouvement visible, qui croît et se répend </p>
                            </div>
                        </div> <br> <br> <br>

                        <!--les row-->
                        <div class="row shadow">
                            <div class="col-lg-6 md-12 my-3">
                                <h1 class="text-success display-5 text-uppercase">Objectifs spécifiques</h1>
                                <ul class="list-group">
                                    <li class="list-group-item">Vivre la fraternité</li>
                                    <li class="list-group-item">Cultiver la maturité</li>
                                    <li class="list-group-item">Rechercher l'excéllence</li>
                                    <li class="list-group-item">Être dynamique et optimiste</li>
                                    <li class="list-group-item">S'approprier l'évangile de Jésus-Christ</li>
                                    <li class="list-group-item">Ecoute, discernement et crainte de Dieu </li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-sm-12 my-3">
                                <h1 class="text-success display-5 text-uppercase">Liturgique et Spirituels</h1>
                                <ul class="list-group">
                                    <li class="list-group-item">Participation aux célébrations et activités paroissiales</li>
                                    <li class="list-group-item">Participation active aux prières du mouvement</li>
                                    <li class="list-group-item">Bon soin de la vie personnelle de prière</li>
                                    <li class="list-group-item">Aborder les questions d'ordre pastorales avec les prêtres de nos communautés</li>
                                </ul>
                            </div>
                        </div>
                        <br> <br> <br>
                        <!--2 eme row-->
                        <div class="row shadow">
                            <div class="col-lg-6 col-sm-6 my-3">
                                <ul class="list-group">
                                    <li class="list-group-item active bg-info">
                                        <h2>Formations</h2>
                                    </li>
                                    <li class="list-group-item">Faire des formations régulières</li>
                                    <li class="list-group-item">Trouver les formateurs adéquats</li>
                                    <li class="list-group-item">Choisir les thème appropriés et attirants</li>
                                    <li class="list-group-item">Amener les membres à s'interesser aux formations et à mettre ses acquis en pratique</li>
                                    <li class="list-group-item">Formation en Informatique (graphisme )</li>
                                </ul>
                            </div>
                            <br><br>
                            <div class="col-lg-6 col-sm-12">
                                <ul class="list-group">
                                    <li class="list-group-item active bg-info">
                                        <h2>&nbsp;&nbsp;Culturelle</h2>
                                    </li>
                                    <li class="list-group-item">Organiser des soirées culturelles ou traditionnelles</li>
                                    <li class="list-group-item">Projection de filmes</li>
                                    <li class="list-group-item">Visite des sites touristiques et culturels</li>
                                    <li class="list-group-item">Apprendre les danses classiques</li>
                                    <li class="list-group-item">Créer un groupe musical</li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <br>
                        <br>
                        <!--3 em row-->
                        <div class="row shadow">
                            <div class="col-lg-6 col-md-12 my-2">
                                <h3 class="text-uppercase text-warning display-4">
                                    Familialle
                                </h3>
                                <ul class="list-group- list-group-flush">
                                    <li class="list-group-item">Visite aux parents des membres du mouvement à domicile</li>
                                    <li class="list-group-item">Organiser de petites rencontres guidées à domicile avec le membres</li>
                                    <li class="list-group-item">Fraterniser avec nos familles</li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-12 my-2">
                                <h3 class="text-uppercase text-warning display-4">
                                    Civique
                                </h3>
                                <ul class="list-group- list-group-flush">
                                    <li class="list-group-item">Connaître les couplets de l'hymne nationnale</li>
                                    <li class="list-group-item">Connaître les droits et devoirs du citoyen</li>
                                    <li class="list-group-item">Poser des actes civiques</li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <br>
                        <br>

                        <!--4 eme row-->
                        <div class="row shadow">
                            <div class="col-lg-6 col-md-12 my-2 mx-auto">
                                <h3 class="text-uppercase text-primary display-6">
                                    Sociale
                                </h3>
                                <ul class="list-group ">
                                    <li class="list-group-item">Etre exemplaire pour son entourage</li>
                                    <li class="list-group-item">Démontrer la spiritualité du mouvement à travers notre mode de vie</li>
                                    <li class="list-group-item">Avoir l'identité de l'Enfant Jésus partout</li>
                                    <li class="list-group-item">Montrer les valeurs acquises dans le mouvement au sein de notre soociété</li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-12 my-2">
                                <h1 class="text-primary">Jours et heures de réunion</h1><br> &nbsp;
                                <ul class="list-group">

                                    <li class="list-group-item"><strong>Adakpamé : tous les dimanches de 10h 15 à 11h45</strong></li>
                                    <li class="list-group-item"><strong>Kagomé   : Tous les dimanches après la messe de 06h</strong></li>
                                    <li class="list-group-item"><strong>Gbényédzi: Tous les dimanches soirs de 15h à 17h </strong></li>
                                    
                                </ul>
                                
                            </div>
                        </div>
                    </div>
        </div>
    </div>
    <!--!content-->

<?php $__env->stopSection(); ?>
<!--End contenu-->

<!--Footer-->
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<!--End footer-->
<?php echo $__env->make('layouts/newlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tobby/ejlaravel/resources/views/programme.blade.php ENDPATH**/ ?>
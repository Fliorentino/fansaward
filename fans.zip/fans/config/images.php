<?php

return ['path'=>'uploads'];

?>